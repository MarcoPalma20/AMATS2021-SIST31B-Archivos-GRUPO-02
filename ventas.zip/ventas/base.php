<?php
$servidor="localhost";
$usuario="root";
$clave="";
$basedeDatos="restaurante";
@$conn=new mysqli($servidor,$usuario,$clave,$basedeDatos);
if($conn->connect_error){
	die("Error reportar al administrador ");
}


?>