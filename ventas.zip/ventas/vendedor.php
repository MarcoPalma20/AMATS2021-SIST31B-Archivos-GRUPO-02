<?php
require_once("base.php");	

?>
<!DOCTYPE html>
<html lang="es-ES">
  <head>
    <link rel="stylesheet" type="text/css" href="vendedor.css">
    <meta charset="utf-8">
    <title>Ventas</title>
  </head>
<body>
    <div id="div">


    <div class="title">
    <p><br><b>Sistema de Facturación</b></p>
    </div>
    <div class="contenedor">
        <div class="tabla1" >
            <br>
            <br><br><br><br>
                <li>Fecha</li>
                <li><input type="datetime" name="fecha" value="<?php
                    echo date('Y-m-d');?>" readonly="readonly"><li>
                <br><br><br>
                <br><br><br>
                <!-- <li>Numero Factura</li>
                <li><input type="number" ></li> -->
            
                <li>Cliente</li>
                <li><input type="text"></li>
                <br><br>
                <li>Vendedor</td>
                <li><select class="td"> 
                    <option></option> 
                </select></li>
        </div>
    </div> 


    <div class="contenedor2">
         <table class="tabla2">
            <tr>
                <td>Codigo de Producto</td>
                <td><input type="text" name="id"></td>
                <td>Cantidad</td>
               <td><input type="number" ></td>
            </tr>
            <tr>
                <td colspan="4"><input class="botons" type="submit" name="agregar"  value="Agregar Producto"></td>
            </tr>
        </table> 
    </div>


    <div class="contenedor3">
        <table id="tabla3"">
        <thead>
        <tr>
            <th>&nbsp;</th>
            <th>idproducto </th>
            <th>nombre</th>	
            <th>cantidad</th>
            <th>costo unitario</th>
            <th>costo total</th>
        </tr>
        </thead>
        <!-- <tr>
        <td>1</td><td>2</td><td>3</td><td>4</td><td>5</td> <td>6</td>
        </tr>
        -->

    
    </table>
    </div>


    <div class="pie">
        <table id="tabla4">
            <tr>
                
                <td colspan="2" >Precio Total&nbsp;&nbsp;<input type="text" readonly="readonly"></td>
                <td><input type="button" name="borar" class="botonscolor" value="Eliminar"></td>
            </tr>
            <tr>
                <td><input class="botonscolor" type="button" value="Cancelar"></td>
                <td ><input class="botons" type="button" value="Generar Venta"></td>
                <td><input class="botonscolor" type="button" name="exit" value="exit" ></td>
            </tr>
        </table>
    </div>
    <!--------------------------->



    </div>


</body>
</html>
