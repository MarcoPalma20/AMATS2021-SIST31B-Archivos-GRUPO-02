<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'admin'){
            header('location: ../login.php');
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de Facturacion | Modificar Usuario</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" >
</head>
<body>
		<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
            <a href="admin.php">Administrador</a>
			<a href="productos.php">Productos</a>
			<a href="ventas.php">Registro de Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>

<form method="post">
    <div id="capa2">
<div id="top">
<table>
 <th colspan="3">  <h1><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
<path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/></svg> Modificar Producto</h1></th>
			<tr>

            <?php
            $idUsuario=$_GET["idUsuario"];
            $sql="select * from usuarios where idUsuario='" . $idUsuario . "'";
            require_once("cn.php");
            $rs=$conn->query($sql);

            while($fila=$rs->fetch_assoc()) {
            $fila["idUsuario"];
            $fila["nombre"];
            $fila["apellido"];
            $fila["edad"];
            $fila["sexo"];
            $fila["telefono"];
            $fila["usuario"];
            $fila["tipo"];
        
            echo "<th colspan='2'> <label for='nombre'>Nombre</label></th>
            <td><input type='text' name='nombre' placeholder='Nombre usuario' required='' value='" . $fila["nombre"] ."'></td>
            </tr>
            <tr>
            <th colspan='2'><label for='apellidos'>Apellido</label></th>
            <td><input type='text' name='apellidos' placeholder='Apellido usuario' value='" . $fila["apellido"] ."'>
            </td>
            </tr><tr>
            <th colspan='2'><label for='edad'>Edad</label></th>
            <td><input type='number' name='edad' placeholder='Edad usuario' required='' value='" . $fila["edad"] ."'></td>
            </tr><tr>
            <th colspan='2'>
            <label for=''>Sexo</label></th>
            <td>
                <select name='sexo[]' required=''>
                        <option value=''><--seleccione una opcion--></option>
                        <option value='Femenino'>Femenino</option>
                        <option value='Masculino'>Masculino</option>
                </td></tr>
            <tr>
            <th colspan='2'><label for='tel'>Telefono</label></th>
            <td><input type='number' name='Telefono' placeholder='Telefono usuario' value='" . $fila["telefono"] ."'>  </td>
            </tr>

            <tr>
                <th colspan='2'><label for='usuario'>Usuario</label></th>
                <td><input type='text' name='usuario' placeholder='Usuario' required='' value='" . $fila["usuario"] ."'></td>
            </tr>

            <tr>
                <th colspan='2'><label for='contra'>Contraseña</label></th>
                <td><input type='password' name='contra' placeholder='Contraseña' required=''></td>
            </tr>

            <tr>
                <th colspan='2'><label for=''>Tipo de Usuario</label></th>
                <td>
                <select name='tipo[]' required='' >
                        <option value=''><--seleccione una opcion--></option>
                        <option value='admin'>Administrador</option>
                        <option value='vendedor'>Vendedor</option>
                </td>
            </tr>";
}
            ?>
			 <tr>
                <td colspan='4' align='center'><input type='submit' name='ok' value='Modificar' class='btn'></td>
            </tr>
            </table>
            </div>
            </div>

        </form>
	</body>
</html>

<?php  
if (isset($_POST["ok"])) {
    $nombre=$_POST["nombre"];
    $apellidos=$_POST["apellidos"];
    $edad=$_POST["edad"];
    $Telefono=$_POST["Telefono"];
    $usuario=$_POST["usuario"];
    $contra=$_POST["contra"];

    if (isset($_POST["sexo"])) {
        $sexo=$_REQUEST["sexo"];

        foreach ($sexo as $sex) {
        }
    }

    if (isset($_POST["tipo"])) {
        $tipo=$_REQUEST["tipo"];

        foreach ($tipo as $rol) {
        }
    }

    require_once("cn.php");
    $sql="update usuarios set nombre='" . $nombre . "', apellido='" . $apellidos . "', edad='" . $edad . "', sexo='" . $sex . "', telefono='" . $Telefono . "', usuario='" . $usuario . "', contra='" . $contra . "', tipo='" . $rol . "' where idUsuario='" . $_GET["idUsuario"] . "'";

    $rs=$conn->query($sql);
    echo "<script>alert('Usuario Modificado Exitosamente');window.location='usuarios.php';</script>";
}

?>

<!--php
    $idproducto=$_GET["idproducto"];
    $sql="select * from productos where idproducto='" . $idproducto . "'";
    require_once("cn.php");
    $rs=$conn->query($sql);

while($fila=$rs->fetch_assoc()) {
    $fila["idproducto"];
    $fila["nombre"];
    $fila["costo"] . "</td>";
   
}
-->
