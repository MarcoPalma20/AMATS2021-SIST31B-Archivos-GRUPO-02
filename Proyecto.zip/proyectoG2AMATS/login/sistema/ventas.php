<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'admin'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Registro de Ventas</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="admin.php">Administrador</a>
			<a href="usuarios.php">Usuarios</a>
			<a href="productos.php">Productos</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->

 <form method="post">
<div id="capa3">
<div id="tap">
<table>
    <thead>
        <tr>
        <th>&nbsp;</th>
        <th>ID factura</th>
        <th>Fecha</th>
         <th>ID cliente</th>
        <th>ID producto</th>
        <th>ID Usuario</th>
        <th>Total</th>
        <th>&nbsp;</th>
    </tr></thead>
 </table>
 </div>
 </div>
</form>
</body>
</html>

<?php  

?>
