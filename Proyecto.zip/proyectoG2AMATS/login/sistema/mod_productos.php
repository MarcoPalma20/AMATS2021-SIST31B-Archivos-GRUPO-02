<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'admin'){
            header('location: ../login.php');
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de Facturacion | Modificar Productos</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" >
</head>
<body>
		<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
            <a href="admin.php">Administrador</a>
			<a href="usuarios.php">Usuarios</a>
			<a href="ventas.php">Registro de Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>

<form method="post">
    <div id="capa2">
<div id="top">
<table>
 <th colspan="3">  <h1><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
<path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/></svg> Modificar Producto</h1></th>
			<tr>

            <?php
            $idproducto=$_GET["idproducto"];
            $sql="select * from productos where idproducto='" . $idproducto . "'";
            require_once("cn.php");
            $rs=$conn->query($sql);

            while($fila=$rs->fetch_assoc()) {
            $fila["idproducto"];
            $fila["nombre"];
            $fila["costo"];

            echo "<th colspan='2'> <label for='Nombre'>Nombre de comida</label></th>
            <td><input type='text' name='nombreProd' placeholder='Nombre comida' required='' value='" . $fila["nombre"] ."'></td>
            </tr>
            <tr>
            <th colspan='2'><label for='precio'>Precio de comida</label></th>
            <td><input type='text' name='precio' placeholder='Precio de comida' required='' value='" . $fila["costo"] ."'>
            </td>
            </tr>";
}
            ?>
			 <tr>
                <td colspan='4' align='center'><input type='submit' name='ok' value='Modificar' class='btn'></td>
            </tr>
            </table>
            </div>
            </div>

        </form>
	</body>
</html>

<?php  
if (isset($_POST["ok"])) {
    $nombre=$_POST["nombreProd"];
    $precio=$_POST["precio"];

    $sql="update productos set nombre='" . $nombre ."', costo='" . $precio . "' where idproducto='" . $_GET["idproducto"] . "'";
    require_once("cn.php");
    $rs=$conn->query($sql);
    echo "<script>alert('Registros Modificados Exitosamente');window.location='productos.php';</script>";
}

?>

<?php
    $idproducto=$_GET["idproducto"];
    $sql="select * from productos where idproducto='" . $idproducto . "'";
    require_once("cn.php");
    $rs=$conn->query($sql);

while($fila=$rs->fetch_assoc()) {
    $fila["idproducto"];
    $fila["nombre"];
    $fila["costo"] . "</td>";
   
}
?>
