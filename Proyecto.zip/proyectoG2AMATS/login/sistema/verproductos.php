<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'vendedor'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de Facturacion | Ver Productos</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" >
</head>
<body>
		<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
            <a href="factura.php">Crear Factura</a>
			<a href="cliente.php">Cliente</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->

<div id="capa1">
<div id="comida" align="center">
<table>
	<thead>
	<tr><th colspan="5">Menu italiano</th></tr>
	</thead>
    <tr>
     	<td>COMIDA</td>
     	<td>PRECIO</td>
     	<td>BEBIDA</td>
     	<td>PRECIO</td>
     </tr>
      <tr>
     	<td>Pasta</td>
     	<td>$5.00</td>
     	<td>Horchata</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>Pizza</td>
     	<td>$10.00</td>
     	<td>Limonada de sandia</td>
     	<td>$2.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS</td>
     	<td>$5.00</td>
     	<td>Frozen de limon</td>
     	<td>$3.00</td>
     </tr>
      <tr>
     	<td>Lasaña</td>
     	<td>$6.00</td>
     	<td>Cafe</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS CON VERDURAS Y POLLO</td>
     	<td>$6.00</td>
     	<td>Té</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS EN SALSA ALFREDO CON POLLO</td>
     	<td>$1.00</td>
     	<td>Soda</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>NSALADA CESAR RECETA CASERA CON POLLO</td>
     	<td>$1.00</td>
     	<td>Licor de Café </td>
     	<td>$3.00</td>
     </tr>


</table>
</div>
</div>

	</body>
</html>

<?php  
    //Mostrando los datos en una tabla
    $sql="select * from productos";
    //agrega la setencia a la bbdd
    require_once("cn.php");
    $rs=$conn->query($sql);
    echo "<form method='post'>
            <div id='capa3'>
            <div id='tap'>
            <table>
                <thead>
                    <tr>
                    <th>&nbsp;</th>
                    <th>ID</th>
                    <th>Nombre de producto</th>
                    <th>Precio de producto</th>
                </tr></thead>";

    while ($fila=$rs-> fetch_assoc()) {
        echo "<tr>";
        echo "<td>&nbsp;</td>";
        echo "<td><b>" . $fila["idproducto"] . "</b></td>";
        echo "<td>" . $fila["nombre"] . "</td>";
        echo "<td>$" . $fila["costo"] . "</td>";
        echo "</tr>";
    }


?>