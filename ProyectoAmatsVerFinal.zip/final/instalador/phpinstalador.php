<?php
if (isset($_POST['oki'])) {
  $base=$POST['base'];
  $usr=$POST['usr'];
  $clave=$POST['clave'];

  //conexion
  $link=mysqli_connect('localhost',$usr,$clave);
  if (!$link) {
    echo "Error, no se puede conectar al servidor ".PHP_EOL;
      exit;
  }
  $sqlbase="create database if not exist ".$base;

  if ($link->query(sqlbase)) {
    echo "proceso terminado";
  }
  $link->select_bd($base);

  $sql=explode(";",file_get_contents('restauranteinstal.sql'))
  foreach ($sql as $query) {
    if ($link->query($query)===TRUE) {
      echo $query. "<br>";
    }
  }
}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form method="post">
      <label for="base">nombre de la base de datos</label>
      <input type="text" name="base" placeholder="introduzca el nombre de la base de datos">
      <label for="base">nombre del usuario</label>
      <input type="text" name="usr" placeholder="introduzca el nombre del usuario ">
      <label for="base">clave de la base de datos</label>
      <input type="text" name="clave" placeholder="introduzca la clave de la base de datos">
      <input type="submit" name="oki" value="crear base de datos">
    </form>

  </body>
</html>
