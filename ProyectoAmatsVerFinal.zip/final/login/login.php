
<?php

 require_once("clases.php");

    $obj=new clsConexion;
    $rs=$obj->consultaGeneral("usuarios","*");

   if($rs->num_rows==0)
   {
    header('location:login0.php');
   }

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="stylelogin.css">
  <title>Inicio</title>
</head>
<body>
  <form action="" method="POST">
  <section class="form-register">
    <h4>Iniciar</h4>
    <br>
    <p><img src="img/u.png" width="50%"></p>
    <br><br><br>
    <br>
    <input class="controls" type="text" name="username"  placeholder="Ingrese su Usuario">
    <input class="controls" type="password" name="password"  placeholder="Ingrese su Contraseña">
    <?php
        include_once 'db.php';

        session_start();

        if(isset($_GET['cerrar_sesion'])){
            session_unset();
            session_destroy();
        }

        if(isset($_SESSION['rol'])){
            switch($_SESSION['rol']){
                case 'admin':
                header('location: sistema/admin.php');
                break;

                case 'vendedor':
                header('location: sistema/verproductos.php');
                break;

                default:
            }
        }

        if(isset($_POST['username']) && isset($_POST['password'])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            $md5 = md5($password);

            $db = new DB();
            $query = $db->connect()->prepare('select * from usuarios where usuario = :username and contra = :password');
            $query->execute(['username' => $username, 'password' => $md5]);

            $row = $query->fetch(PDO::FETCH_NUM);

            if($row == true){
                $rol = $row[8];

                $_SESSION['rol'] = $rol;
                switch($rol){
                    case 'admin':
                        header('location: sistema/admin.php');
                    break;

                    case 'vendedor':
                    header('location: sistema/verproductos.php');
                    break;

                    default:
                }
            }else{
                echo "Nombre de usuario o contraseña incorrecto";
            }


        }

    ?>
    <input class="botons" type="submit" value="Iniciar">
    <p>Estoy de acuerdo con <a href="#">Terminos y Condiciones</a></p>

  </section>
  </form>

</body>
</html>
