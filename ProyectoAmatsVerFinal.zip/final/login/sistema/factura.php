<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'vendedor'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Facturización</title>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <LINK REL=StyleSheet HREF="estilo1.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="contacto.php">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="cliente.php">Cliente</a>
			<a href="verproductos.php">Ver Productos</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->

<form method="post">
	<div id="capa3">
<div id="factura">
<table>
	 <th colspan="3"> <img src="ima/in.jpg" width="40%">
 <h2>RESTAURANTE PARADISO  | Facturación</h2></th>
			<tr>
				<th colspan="2"><label for="fecha">Fecha</label></th>
				<td><input type="datetime" name="fecha" readonly="" value="<?php echo date('Y-m-d');?>"></td>
			</tr>

			<tr>
				<th colspan="2"><label for="cliente">Cliente</label></th>
				<td>
					<select name="cliente[]" required="">
						<option value="">---Elija Un cliente---</option>
						<?php
							require_once("cn.php");
							$sql="select * from clientes";
							$rs=$conn->query($sql);

							while ($fila=$rs->fetch_assoc()) {
								echo "<option value='$fila[idCliente]'>$fila[nombre]</option>";
							}
						?>
					</select>
				</td>
			</tr>

			<tr>
				<th colspan="2"><label for="empleado">Empleado</label></th>
				<td>
					<select name="empleado[]" required="">
						<option value="">---Elija Un empleado---</option>
						<?php
							require_once('cn.php');
							$sql="select * from usuarios";
							$rs=$conn->query($sql);

							while ($fila=$rs->fetch_assoc()) {
								echo "<option value='$fila[idUsuario]'>$fila[nombre]</option>";
							}
						?>
					</select>
				</td>
			</tr>

			<tr>
				<th colspan="2"><label>Producto</label></th>
				<td>
					<select name="producto[]" required="">
						<option value="">---Elija Un Producto---</option>
						<?php
							require_once('cn.php');
							$sql="select * from productos";
							$rs=$conn->query($sql);

							while ($fila=$rs->fetch_assoc()) {
								echo "<option value='$fila[idproducto]'>$fila[nombre]</option>";
							}
						?>

					</select>
				</td>
			</tr>

			<tr>
			<th colspan="2"><label for="cantidad">Cantidad</label></th>
			<td><input type="number" name="cantidad" placeholder="Cantidad" required="" min="0">
			</td>
			</tr>
			<!-- <tr>
			<th colspan="2"><label for="cantidad">Total</label></th>
			<td><input class="texto" type="text" name="tp" id="total" placeholder="Total a Pagar" >


			<!--------------ACA IRIA EL TOTAL LA CANTIDAD POR EL COSTO DEL PRODUCTO XD------------->
			</td>

			</tr> -->

            <tr>
        <td colspan="4" align="center"  >
        <input class="btn04"  type="submit" name="ok" value="Generar Venta"></td>
            </tr>
            </table>
            </div>
            </div>
		</form>

	<?php



if (isset($_POST["ok"]))
{
		require_once("cn.php");
		$fecha=$_POST["fecha"];
		$cantidad=$_POST["cantidad"];

		if (isset($_POST["cliente"])) {
			$cliente=$_REQUEST["cliente"];

			foreach ($cliente as $idCliente) {
			}
		}

		if (isset($_POST["empleado"])) {
			$empleado=$_REQUEST["empleado"];

			foreach ($empleado as $idUsuario) {
			}
		}

		if (isset($_POST["producto"])) {
			$producto=$_REQUEST["producto"];

			foreach ($producto as $idproducto) {
			}
		}

		$costo="select costo from productos where idproducto=" . $idproducto . "";
		$rs=$conn->query($costo);
		while ($fila=$rs->fetch_assoc()) {
		$precio=$fila["costo"];
		}

		$total=$cantidad*$precio;

		echo "<script>alert('Total a Cancelar :$total');</script>";

		require_once("cn.php");
		$sqlinsert="INSERT INTO CodFactura (fecha, idCliente, idproducto, cantidad, idUsuario, total)
		VALUES ('$fecha', '$idCliente', '$idproducto', '$cantidad', '$idUsuario', '$total')";



		$rs=$conn->query($sqlinsert);

		 echo "<script>swal('Guardado', 'Factura Creada Exitosamente', 'success');</script>";



}

else {
	echo "<script>swal('Vamos a Crear una Factura');</script>";
}







?>


      <div id="tablapagar">

      </div>
        <?php
        echo " </div>"; ?>

</body>
</html>
