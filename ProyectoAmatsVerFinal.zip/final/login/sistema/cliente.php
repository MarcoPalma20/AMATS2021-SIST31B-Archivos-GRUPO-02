<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'vendedor'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Cliente</title>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <LINK REL=StyleSheet HREF="estilo1.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="contacto.php">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="verproductos.php">Ver Productos</a>
			<a href="factura.php">Crear Factura</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->

<!--	tabla--------------->
<form method="post">
	<div id="capa3">
<div id="top">
<table>
	 <th colspan="2">
  <h2><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-building" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M14.763.075A.5.5 0 0 1 15 .5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V14h-1v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V10a.5.5 0 0 1 .342-.474L6 7.64V4.5a.5.5 0 0 1 .276-.447l8-4a.5.5 0 0 1 .487.022zM6 8.694 1 10.36V15h5V8.694zM7 15h2v-1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5V15h2V1.309l-7 3.5V15z"/>
  <path d="M2 11h1v1H2v-1zm2 0h1v1H4v-1zm-2 2h1v1H2v-1zm2 0h1v1H4v-1zm4-4h1v1H8V9zm2 0h1v1h-1V9zm-2 2h1v1H8v-1zm2 0h1v1h-1v-1zm2-2h1v1h-1V9zm0 2h1v1h-1v-1zM8 7h1v1H8V7zm2 0h1v1h-1V7zm2 0h1v1h-1V7zM8 5h1v1H8V5zm2 0h1v1h-1V5zm2 0h1v1h-1V5zm0-2h1v1h-1V3z"/>
</svg> Agregar Cliente</h2></th>

	<tr>
			<th colspan="2"> <label for="nombre">Nombre</label></th>
			<td><input type="text" name="nombre" placeholder="Nombre Cliente"></td>
			</tr>
            <tr>
                 <td colspan="4" align="center"  >
        <input class="btn"  type="submit" name="ok" value="Agregar"/></td>
            </tr>
            </table>
            </div>
             </div>
		</form>
<!--	fin tabla--------------->
</body>
</html>

<?php
if (isset($_POST["ok"])) {
	$nombre=$_POST["nombre"];

	require_once("cn.php");

	$sql="insert into clientes (nombre) values ('$nombre')";

	$rs=$conn->query($sql);
	echo "<script>swal('Guardado', 'Usuario Agregado Exitosamente', 'success');</script>";

}
elseif (isset($_POST["okeliminar"])) {
    $dato=$_POST["eliminar"];
    require_once("cn.php");
    foreach ($dato as $elemento) {
        $sqlDel="delete from clientes where idCliente='$elemento'";
        $rs=$conn->query($sqlDel);
    }


	echo "<script>swal('Eliminado', 'Cliente Eliminado Exitosamente', 'error');</script>";

}
?>

<?php
$sql="select * from clientes";
require_once("cn.php");
$rs=$conn->query($sql);

echo "<form method='post'>
<div id='capa3'>
<div id='tap'>
<table>
    <thead>
        <tr>
        <th>#</th>
        <th>ID</th>
        <th>Nombre</th>
    </tr></thead>";

while ($fila=$rs-> fetch_assoc()) {
	echo "<tr>";
	echo "<td><input type='checkbox' name='eliminar[]' value='". $fila["idCliente"] ."' title='Eliminar " . $fila["nombre"] ."'</td>";
	echo "<td><b>" . $fila["idCliente"] . "</b></td>";
	echo "<td>" . $fila["nombre"] . "</td>";
}

echo " <tr>
        <td colspan='8' align='center'  >
        <input class='btn'  type='submit' name='okeliminar' value='Eliminar'/></td>
    </tr>
    </table>
        </div>
        </div>
        </form>";

?>
