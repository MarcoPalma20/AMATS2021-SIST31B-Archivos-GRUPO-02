<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilocontacto.css">
	<title>contacto</title>
</head>
<body>
	<form action="" class="formulario">
  <h1 class="formulario__titulo">Contáctenos</h1>
  <input type="text" class="formulario__input">
  <label for="" class="formulario__label">Nombres</label>
  <input type="text" class="formulario__input">
  <label for="" class="formulario__label">Correo</label>
  <input type="text" class="formulario__input">
  <label for="" class="formulario__label">Teléfono</label>
  <input type="text" class="formulario__input">
  <label for="" class="formulario__label">Mensaje</label>
  <input type="submit" class="formulario__submit">
</form>
<script type="text/javascript">
	var inputs = document.getElementsByClassName('formulario__input');
for (var i = 0; i < inputs.length; i++) {
  inputs[i].addEventListener('keyup', function(){
    if(this.value.length>=1) {
      this.nextElementSibling.classList.add('fijar');
    } else {
      this.nextElementSibling.classList.remove('fijar');
    }
  });
}
</script>


</body>
</html>
