<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'admin'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Registro de Ventas</title>
 <LINK REL=StyleSheet HREF="estilo1.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="contacto.php">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="admin.php">Administrador</a>
			<a href="usuarios.php">Usuarios</a>
			<a href="productos.php">Productos</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
</body>
</html>

<?php
//mostrando los datos de la tabla usuarios
 $sql="select * from CodFactura";
  //agrega la setencia a la bbdd
 	require_once("cn.php");
    $rs=$conn->query($sql);

    echo "<form method='post'>
			<div id='capa3'>
			<div id='tap'>
			<table>
			    <thead>
			        <tr>
			        <th>ID Factura</th>
			        <th>Fecha</th>
			        <th>idCliente</th>
			        <th>idproducto</th>
			        <th>idUsuario</th>
			        <th>Cantidad</th>
			        <th>total</th>
			    </tr></thead>";

	while ($fila=$rs-> fetch_assoc()) {
		echo "<tr>";
		echo "<td>". $fila["idFactura"] . "</td>";
		echo "<td>". $fila["fecha"] . "</td>";
		echo "<td>". $fila["idCliente"] ."</td>";
		echo "<td>". $fila["idproducto"] ."</td>";
		echo "<td>". $fila["idUsuario"] ."</td>";
		echo "<td>". $fila["cantidad"] . "</td>";
		echo "<td>$". round($fila["total"], 2) ."</td>";
		echo "</tr>";
 }

 echo "</table>
 </div>
 </div>
</form>";


?>
