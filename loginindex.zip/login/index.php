<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="stylelogin.css">
  <title>Inicio</title>
</head>
<body>
  <section class="form-register">
    <h4>Iniciar</h4>
    <br>
    <p><img src="img/u.png" width="50%"></p>
    <br><br><br>
    <br>
    <input class="controls" type="text" name="usuario"  placeholder="Ingrese su Usuario">
    <input class="controls" type="password" name="contra"  placeholder="Ingrese su Contraseña">
    <p>Estoy de acuerdo con <a href="#">Terminos y Condiciones</a></p>
    <input class="botons" type="submit" value="Iniciar">
    <p><a href="#">¿He olvidado mi contrasena?</a></p>
  </section>

</body>
</html>
