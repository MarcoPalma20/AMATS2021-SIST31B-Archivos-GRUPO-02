<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de Facturacion | productos</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" >
</head>
<body>
		<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="#">Inicio</a>
				<a href="#">Nosotros</a> 
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="usuarios.php">Usuarios</a>
			<a href="proveedores.php">Proveedores</a>
			<a href="productos.php">Productos</a>
			<a href="ventas.php">Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->

<div id="capa1">
<div id="comida" align="center"> 
<table>
	<thead>  
	<tr><th colspan="5">Menu italiano</th></tr>
	</thead>
    <tr>
     	<td>COMIDA</td>
     	<td>PRECIO</td>
     	<td>BEBIDA</td>
     	<td>PRECIO</td>
     </tr>
      <tr>
     	<td>Pasta</td>
     	<td>$5.00</td>
     	<td>Horchata</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>Pizza</td>
     	<td>$10.00</td>
     	<td>Limonada de sandia</td>
     	<td>$2.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS</td>
     	<td>$5.00</td>
     	<td>Frozen de limon</td>
     	<td>$3.00</td>
     </tr>
      <tr>
     	<td>Lasaña</td>
     	<td>$6.00</td>
     	<td>Cafe</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS CON VERDURAS Y POLLO</td>
     	<td>$6.00</td>
     	<td>Té</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>ESPAGUETIS EN SALSA ALFREDO CON POLLO</td>
     	<td>$1.00</td>
     	<td>Soda</td>
     	<td>$1.00</td>
     </tr>
      <tr>
     	<td>NSALADA CESAR RECETA CASERA CON POLLO</td>
     	<td>$1.00</td>
     	<td>Licor de Café </td>
     	<td>$3.00</td>
     </tr>
    

</table>
</div>
</div>

<form method="post">
    <div id="capa2">
<div id="top"> 
<table>
 <th colspan="2">  <h1><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
<path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/></svg>Productos</h1></th>
			<tr> 
			<th colspan="2"> <label for="comida">Comida</label></th>
			<td><input type="text" name="comida" placeholder="Nombre comida"></td>
			</tr>
			<tr> 
			<th colspan="2"><label for="cantidad">cantidad</label></th>
			<td><input type="text" name="cantidad" placeholder="Cantidad de comida">
			</td>
			</tr><tr> 
			<th colspan="2"><label for="bebida">Bebida</label></th>
			<td><input type="text" name="bebida" placeholder="Nombre Bebida">	</td>
			</tr><tr> 
			<th colspan="2">
            <label for="cantidad">cantidad</label></th>
			<td><input type="text" name="cantidad" placeholder="cantidad de bebida">
            	</td></tr>
            <tr>
            	<td><input type="submit" name="" value="Enviar datos" class="btn"></td>
            	<td><input type="submit" name="" value="Eliminar" class="btn"></td>
            	<td><input type="submit" name="" value="Modificar" class="btn"></td>
            </tr>
			</table>
			</div>
            </div>
           
		</form> 
	</body>
</html>