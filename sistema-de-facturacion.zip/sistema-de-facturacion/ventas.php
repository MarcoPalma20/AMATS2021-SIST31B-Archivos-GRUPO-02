<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Ventas</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="#">Inicio</a>
				<a href="#">Nosotros</a> 
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="usuarios.php">Usuarios</a>
			<a href="proveedores.php">Proveedores</a>
			<a href="productos.php">Productos</a>
			<a href="ventas.php">Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->
<form method="post">
	<div id="capa3">
<div id="top"> 
<table>
	 <th colspan="2">
  <h2><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
  <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
</svg>Registro Ventas</h2></th>

	<tr> 
			<th colspan="2"> <label for="comida">Comida</label></th>
			<td><input type="text" name="comida" placeholder="Nombre comida"></td>
			</tr>
			<tr> 
			<th colspan="2"><label for="cantidad">cantidad</label></th>
			<td><input type="text" name="cantidad" placeholder="Cantidad de comida">
			</td>
			</tr><tr> 
			<th colspan="2"><label for="bebida">Bebida</label></th>
			<td><input type="text" name="bebida" placeholder="Nombre Bebida">	</td>
			</tr><tr> 
			<th colspan="2">
            <label for="cantidad">cantidad</label></th>
			<td><input type="text" name="cantidad" placeholder="cantidad de bebida">
            	</td></tr>
            <tr>
            	<td><input type="submit" name="" value="Enviar datos" class="btn"></td>
            	<td><input type="submit" name="" value="Eliminar" class="btn"></td>
            	<td><input type="submit" name="" value="Modificar" class="btn"></td>
            </tr>
            </table>
            </div>
            </div>
		</form>
</body>
</html>