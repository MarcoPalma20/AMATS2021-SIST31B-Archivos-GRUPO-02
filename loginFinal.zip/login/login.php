
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="stylelogin.css">
  <title>Inicio</title>
</head>
<body>
  <form action="" method="POST">
  <section class="form-register">
    <h4>Iniciar</h4>
    <br>
    <p><img src="img/u.png" width="50%"></p>
    <br><br><br>
    <br>
    <input class="controls" type="text" name="username"  placeholder="Ingrese su Usuario">
    <input class="controls" type="password" name="password"  placeholder="Ingrese su Contraseña">
    <?php
        include_once 'db.php';

        session_start();

        if(isset($_GET['cerrar_sesion'])){
            session_unset();
            session_destroy();
        }

        if(isset($_SESSION['rol'])){
            switch($_SESSION['rol']){
                case 'admin':
                header('location: admin.php');
                break;

                case 'vendedor':
                header('location: vendedor.php');
                break;

                default:
            }
        }

        if(isset($_POST['username']) && isset($_POST['password'])){
            $username = $_POST['username'];
            $password = $_POST['password'];

            $db = new DB();
            $query = $db->connect()->prepare('SELECT *FROM usuarios WHERE usuario = :username AND contra = :password');
            $query->execute(['username' => $username, 'password' => $password]);

            $row = $query->fetch(PDO::FETCH_NUM);

            if($row == true){
                $rol = $row[8];

                $_SESSION['rol'] = $rol;
                switch($rol){
                    case 'admin':
                        header('location: admin.php');
                    break;

                    case 'vendedor':
                    header('location: vendedor.php');
                    break;

                    default:
                }
            }else{
                echo "Nombre de usuario o contraseña incorrecto";
            }


        }

    ?>
    <input class="botons" type="submit" value="Iniciar">
    <p>Estoy de acuerdo con <a href="#">Terminos y Condiciones</a></p>
    <p><a href="#">¿He olvidado mi contrasena?</a></p>
  </section>
  </form>

</body>
</html>
