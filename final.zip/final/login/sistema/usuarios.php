<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'admin'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Usuario</title>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <LINK REL=StyleSheet HREF="estilo1.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="admin.php">Administrador</a>
			<a href="productos.php">Productos</a>
			<a href="ventas.php">Registro de Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->
<form method="post">
	<div id="capa3">
<div id="top">
<table>
	 <th colspan="2">
  <h2><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
  <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
  <path fill-rule="evenodd" d="M5.216 14A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216z"/>
  <path d="M4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"/>
</svg> Agregar Usuario</h2></th>

			<tr>
			<th colspan="2"> <label for="nombre">Nombre</label></th>
			<td><input type="text" name="nombre" placeholder="Nombre usuario" required=""></td>
			</tr>
			<tr>
			<th colspan="2"><label for="apellidos">Apellido</label></th>
			<td><input type="text" name="apellidos" placeholder="Apellido usuario">
			</td>
			</tr><tr>
			<th colspan="2"><label for="edad">Edad</label></th>
			<td><input type="number" name="edad" placeholder="Edad usuario" required="" min="0"></td>
			</tr><tr>
			<th colspan="2">
            <label for=" ">Sexo</label></th>
			<td>
				<select name="sexo[]" required="" >
						<option value=""><--seleccione una opcion--></option>
						<option value="Femenino">Femenino</option>
						<option value="Masculino">Masculino</option>
            	</td></tr>
            <tr>
			<th colspan="2"><label for="tel">Telefono</label></th>
			<td><input type="number" name="Telefono" placeholder="Telefono usuario" min="0">	</td>
			</tr>

			<tr>
				<th colspan="2"><label for="usuario">Usuario</label></th>
				<td><input type="text" name="usuario" placeholder="Usuario" required=""></td>
			</tr>

			<tr>
				<th colspan="2"><label for="contra">Contraseña</label></th>
				<td><input type="password" name="contra" placeholder="Contraseña" required="" ></td>
			</tr>

			<tr>
				<th colspan="2"><label for="">Tipo de Usuario</label></th>
				<td>
				<select name="tipo[]" required="" >
						<option value=""><--seleccione una opcion--></option>
						<option value="admin">Administrador</option>
						<option value="vendedor">Vendedor</option>
            	</td>
			</tr>

            <tr>
        <td colspan="4" align="center"  >
        <input class="btn"  type="submit" name="ok" value="Agregar"/></td>
            </tr>
            </table>
            </div>
            </div>
		</form>
</body>
</html>

<?php
if (isset($_POST["ok"])) {
	$nombre=$_POST["nombre"];
	$apellidos=$_POST["apellidos"];
	$edad=$_POST["edad"];
	$Telefono=$_POST["Telefono"];
	$usr=$_POST["usuario"];
	$contra=md5($_POST["contra"]);

	if (isset($_POST["sexo"])) {
		$sexo=$_REQUEST["sexo"];

		foreach ($sexo as $sex) {
		}
	}

	if (isset($_POST["tipo"])) {
		$tipo=$_REQUEST["tipo"];

		foreach ($tipo as $rol) {
		}
	}

	require_once("cn.php");
	$sql="insert into usuarios (nombre, apellido, edad, sexo, telefono, usuario, contra, tipo)
    values ('$nombre', '$apellidos', '$edad', '$sex', '$Telefono', '$usr', '$contra', '$rol')";

    $rs=$conn->query($sql);
	
    echo"<script>swal('Guardado','Usuario Agregado Exitosamente','success');</script>";
}
elseif (isset($_POST["okeliminar"])) {
	$dato=$_POST["eliminar"];
	require_once("cn.php");
	foreach ($dato as $elemento) {
		$sqlDel="delete from usuarios where idUsuario='$elemento'";
        $rs=$conn->query($sqlDel);
	}
	
	echo"<script>swal('Eliminado','Usuario Eliminado Exitosamente','error');</script>";
}

?>

<?php
//mostrando los datos de la tabla usuarios
 $sql="select * from usuarios";
  //agrega la setencia a la bbdd
 	require_once("cn.php");
    $rs=$conn->query($sql);

    echo "<form method='post'>
			<div id='capa3'>
			<div id='tap'>
			<table>
			    <thead>
			        <tr>
			        <th>#</th>
			        <th>ID</th>
			        <th>Nombre</th>
			        <th>Apellido</th>
			        <th>Edad</th>
			        <th>sexo</th>
			        <th>Telefono</th>
			        <th>Usuario</th>
			        <th>Tipo</th>
			        <th>#</th>
			    </tr></thead>";

	while ($fila=$rs-> fetch_assoc()) {
		echo "<tr>";
		echo "<td><input type='checkbox' name='eliminar[]' value='". $fila["idUsuario"] ."' title='Eliminar " . $fila["nombre"] ."'</td>";
		echo "<td>". $fila["idUsuario"] . "</td>";
		echo "<td>". $fila["nombre"] . "</td>";
		echo "<td>". $fila["apellido"] ."</td>";
		echo "<td>". $fila["edad"] ."</td>";
		echo "<td>". $fila["sexo"] ."</td>";
		echo "<td>". $fila["telefono"] ."</td>";
		echo "<td>". $fila["usuario"] . "</td>";
		echo "<td>". $fila["tipo"] . "</td>";
		echo "<td><a href='mod_usuarios.php?idUsuario=$fila[idUsuario]'>Modificar</a></td>";
 }

 echo "<tr>
        <td colspan='10' align='center'  >
        <input class='btn'  type='submit' name='okeliminar' value='Eliminar'/></td>
    </tr>
 </table>
 </div>
 </div>
</form>";


?>
