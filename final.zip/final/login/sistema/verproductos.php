<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'vendedor'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de Facturacion | Ver Productos</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <LINK REL=StyleSheet HREF="estilo1.css" TYPE="text/css" >
</head>
<body>
    <script>swal('Bienvenido');</script>";
		<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
            <a href="factura.php">Crear Factura</a>
			<a href="cliente.php">Cliente</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->



	</body>
</html>

<?php  
    //Mostrando los datos en una tabla
    $sql="select * from productos";
    //agrega la setencia a la bbdd
    require_once("cn.php");
    $rs=$conn->query($sql);
    echo "<form method='post'>
            <div id='capa3'>
            <div id='tap'>
            <table>
                <thead>
                    <tr>
                    <th>&nbsp;</th>
                    <th>ID</th>
                    <th>Nombre de producto</th>
                    <th>Precio de producto</th>
                </tr></thead>";

    while ($fila=$rs-> fetch_assoc()) {
        echo "<tr>";
        echo "<td>&nbsp;</td>";
        echo "<td><b>" . $fila["idproducto"] . "</b></td>";
        echo "<td>" . $fila["nombre"] . "</td>";
        echo "<td>$" . $fila["costo"] . "</td>";
        echo "</tr>";
    }


?>