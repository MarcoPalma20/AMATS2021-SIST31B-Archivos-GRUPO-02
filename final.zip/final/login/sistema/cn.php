<?php
	$servidor="localhost";
    $usuario="root";
    $clave="";
    $base="restaurante";

    //creando la conexion a la base restaurante
    $conn = new mysqli ($servidor, $usuario, $clave, $base);

    if ($conn->connect_error) {
        die('Error');
    }
    else {
    }



   
?>