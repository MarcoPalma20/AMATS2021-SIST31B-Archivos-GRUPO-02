<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: ../login.php');
    }else{
        if($_SESSION['rol'] != 'vendedor'){
            header('location: ../login.php');
        }
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Facturacion | Usuario</title>
 <LINK REL=StyleSheet HREF="estilo.css" TYPE="text/css" MEDIA=screen>
</head>
<body>
<header class="header">
		<div class="container-con">
		<div class="btn-menu">
			<label for="btn-menu">☰</label>
		</div>
			<div class="logo">
				<h1> Sistema de Facturacion</h1>

			</div>
			<nav class="menu">
				<a href="borrar.php">Cerrar Sesion</a>
				<a href="#">Nosotros</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
	<div class="capa"></div>
<!-- --------------->
<input type="checkbox" id="btn-menu">
<div class="container-menu">
	<div class="cont-menu">
		<nav>
			<a href="cliente.php">Clientes</a>
			<a href="productos.php">Productos</a>
			<a href="ventas.php">Ventas</a>
		</nav>
		<label for="btn-menu">✖️</label>
	</div>
</div>
<!--	fin menu--------------->
<form method="post">
	<div id="capa3">
<div id="top">
<table>
	 <th colspan="2">
  <h2><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
  <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
  <path fill-rule="evenodd" d="M5.216 14A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216z"/>
  <path d="M4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"/>
</svg>Usuario</h2></th>

	<tr>
			<th colspan="2"> <label for="comida">Nombre</label></th>
			<td><input type="text" name="comida" placeholder="Nombre usuario"></td>
			</tr>
			<tr>
			<th colspan="2"><label for="cantidad">Apellido</label></th>
			<td><input type="text" name="cantidad" placeholder="Apellido usuario">
			</td>
			</tr><tr>
			<th colspan="2"><label for="bebida">Edad</label></th>
			<td><input type="text" name="bebida" placeholder="Edad usuario">	</td>
			</tr><tr>
			<th colspan="2">
            <label for=" ">Sexo</label></th>
			<td>
				<select name=" " required="" >
						<option value=""><--seleccione una opcion--></option>
						<option value="3">Femenino</option>
						<option value="8">Masculino</option>
            	</td></tr>
            <tr>
			<th colspan="2"><label for="tel">Telefono</label></th>
			<td><input type="text" name="Telefono" placeholder="Edad usuario">	</td>
			</tr>

            <tr>
        <td colspan="4" align="center"  >
        <input class="btn"  type="submit" name="ok" value="Agregar"/></td>
            </tr>
            </table>
            </div>
            </div>
		</form>
 <form method="post">
<div id="capa3">
<div id="tap">
<table>
    <thead>
        <tr>
        <th>&nbsp;</th>
        <th>ID</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Edad</th>
        <th>sexo</th>
        <th>Telefono</th>
        <th>&nbsp;</th>
    </tr></thead>
     <?php
     ?>
        <tr>
        <td colspan="8" align="center"  >
        <input class="btn"  type="submit" name="okeliminar" value="Eliminar"/></td>
    </tr>
 </table>
 </div>
 </div>
</form>


</body>
</html>
